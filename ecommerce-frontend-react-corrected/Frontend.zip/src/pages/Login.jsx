import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function Login() {
  const { login } = useApp();
  const nav = useNavigate();

  const [email, setEmail] = useState("user@example.com");
  const [password, setPassword] = useState("user123");
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();

    const r = await login(email, password);

    if (!r.ok) {
      return setError(r.message);
    }

    nav(
      r.user.role === "USER"
        ? "/user/home"
        : r.user.role === "VENDOR"
          ? "/vendor/dashboard"
          : "/admin/dashboard",
    );
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm">
            <div className="card-body p-4">
              <h2>Login</h2>

              {error && <div className="alert alert-danger">{error}</div>}

              <form onSubmit={submit}>
                <label>Email</label>
                <input
                  type="email"
                  className="form-control mb-3"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />

                <label>Password</label>
                <input
                  type="password"
                  className="form-control mb-3"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />

                <button className="btn btn-primary w-100">Login</button>
              </form>

              <hr />

              <small>
                User: user@example.com / user123
                <br />
                Vendor: vendor@example.com / vendor123
                <br />
                Admin: admin@example.com / admin123
                <br />
                Pending vendor: pending@example.com / vendor123
              </small>

              <div className="mt-3">
                <Link to="/register">Create account</Link>
                {" · "}
                <Link to="/vendor/register">Become a vendor</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
