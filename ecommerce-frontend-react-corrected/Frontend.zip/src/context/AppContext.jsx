import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { api } from "../api/client";

const C = createContext(null);

const normalizeProduct = (p) => ({
  ...p,
  id: p._id || p.id,
  image: p.imageUrl || p.image || "",
});

const normalizeUser = (u) => ({
  ...u,
  id: u._id || u.id,
});

const normalizeVendor = (v) => ({
  ...v,
  id: v._id || v.id,
  userId: v.userId?._id || v.userId,
});

const normalizeAddress = (a) => ({
  ...a,
  id: a._id || a.id,
});

const normalizeReview = (r) => ({
  ...r,
  id: r._id || r.id,
  userId: r.userId?._id || r.userId,
  productId: r.productId?._id || r.productId,
});

const normalizeOrder = (o) => ({
  ...o,
  id: o._id || o.id,
  userId: o.userId?._id || o.userId,
  addressId: o.addressId?._id || o.addressId,
  items: (o.items || []).map((i) => ({
    ...i,
    id: i._id || i.id,
    orderId: i.orderId?._id || i.orderId,
    productId: i.productId?._id || i.productId,
    vendorId: i.vendorId?._id || i.vendorId,
    tracking: i.tracking || [],
  })),
});

const normalizeIssue = (i) => ({
  ...i,
  id: i._id || i.id,
  userId: i.userId?._id || i.userId,
  assignedTo: i.assignedTo?._id || i.assignedTo || null,
  orderId: i.orderId?._id || i.orderId || null,
  productId: i.productId?._id || i.productId || null,
});

export function AppProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("shopsphereUser") || "null");
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(() => localStorage.getItem("shopsphereToken"));
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [cartTotal, setCartTotal] = useState(0);
  const [orders, setOrders] = useState([]);
  const [addresses, setAddresses] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [issues, setIssues] = useState([]);
  const [users, setUsers] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) localStorage.setItem("shopsphereUser", JSON.stringify(user));
    else localStorage.removeItem("shopsphereUser");
  }, [user]);

  useEffect(() => {
    if (token) localStorage.setItem("shopsphereToken", token);
    else localStorage.removeItem("shopsphereToken");
  }, [token]);

  const loadProducts = useCallback(async () => {
    const data = await api.get("/products?limit=100");
    setProducts((data.items || []).map(normalizeProduct));
    return data;
  }, []);

  const loadCart = useCallback(async () => {
    if (!user || user.role !== "USER") {
      setCartItems([]);
      setCartTotal(0);
      return;
    }
    const data = await api.get("/cart");
    const items = (data.items || []).map((i) => ({
      ...i,
      id: i.id || i._id,
      productId: i.productId?._id || i.productId,
      product: normalizeProduct(i.product || {}),
    }));
    setCartItems(items);
    setCartTotal(data.total || 0);
  }, [user]);

  const loadUserData = useCallback(async () => {
    if (!user) return;

    if (user.role === "USER") {
      const [addressData, orderData, issueData] = await Promise.all([
        api.get("/addresses"),
        api.get("/orders"),
        api.get("/issues"),
      ]);

      setAddresses((addressData || []).map(normalizeAddress));
      setOrders((orderData || []).map(normalizeOrder));
      setIssues((issueData || []).map(normalizeIssue));
      await loadCart();
    }

    if (user.role === "VENDOR") {
      const [vendorData, orderData, issueData] = await Promise.all([
        api.get("/vendor/profile"),
        api.get("/orders/vendor/list"),
        api.get("/issues"),
      ]);

      setVendors([normalizeVendor(vendorData)]);
      setOrders((orderData || []).map(normalizeOrder));
      setIssues((issueData || []).map(normalizeIssue));
    }

    if (user.role === "ADMIN") {
      const [vendorData, userData, orderData, issueData] = await Promise.all([
        api.get("/admin/vendors"),
        api.get("/admin/users"),
        api.get("/orders/admin/list"),
        api.get("/admin/issues"),
      ]);

      setVendors((vendorData || []).map(normalizeVendor));
      setUsers((userData || []).map(normalizeUser));
      setOrders((orderData || []).map(normalizeOrder));
      setIssues((issueData || []).map(normalizeIssue));
    }
  }, [user, loadCart]);

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        await loadProducts();

        if (token) {
          const me = await api.get("/auth/me");
          if (active) setUser(normalizeUser(me));
        }
      } catch (error) {
        if (error.status === 401 || error.status === 403) {
          setToken(null);
          setUser(null);
        }
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [token, loadProducts]);

  useEffect(() => {
    if (!loading && user) {
      loadUserData().catch(console.error);
    }
  }, [loading, user, loadUserData]);

  const login = async (email, password) => {
    try {
      const data = await api.post("/auth/login", { email, password });
      const nextUser = normalizeUser(data.user);
      setToken(data.token);
      setUser(nextUser);
      await loadProducts();
      return { ok: true, user: nextUser };
    } catch (error) {
      return { ok: false, message: error.message };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setCartItems([]);
    setCartTotal(0);
    setAddresses([]);
    setOrders([]);
    setIssues([]);
    setReviews([]);
    setUsers([]);
    setVendors([]);
  };

  const registerUser = async (data) => {
    try {
      await api.post("/auth/register", data);
      return { ok: true };
    } catch (error) {
      return { ok: false, message: error.message };
    }
  };

  const registerVendor = async (data) => {
    try {
      await api.post("/auth/vendor/register", data);
      return { ok: true };
    } catch (error) {
      return { ok: false, message: error.message };
    }
  };

  const addToCart = async (product, quantity = 1) => {
    if (!user || user.role !== "USER" || !product?.stock) return;
    try {
      await api.post("/cart/items", {
        productId: product.id,
        quantity,
      });
      await loadCart();
    } catch (error) {
      throw error;
    }
  };

  const removeFromCart = async (id) => {
    const item = cartItems.find((x) => x.productId === id);
    if (!item) return;
    await api.delete(`/cart/items/${item.id}`);
    await loadCart();
  };

  const updateCartQty = async (id, quantity) => {
    const item = cartItems.find((x) => x.productId === id);
    if (!item) return;

    if (quantity <= 0) {
      await removeFromCart(id);
      return;
    }

    await api.patch(`/cart/items/${item.id}`, { quantity });
    await loadCart();
  };

  const placeOrder = async (addressId) => {
    const data = await api.post("/orders", { addressId });
    const order = normalizeOrder(data);
    await Promise.all([loadCart(), loadProducts()]);
    setOrders((prev) => [order, ...prev.filter((o) => o.id !== order.id)]);
    return order;
  };

  const loadOrder = async (id) => {
    const data = await api.get(`/orders/${id}`);
    return normalizeOrder(data);
  };

  const updateVendorOrderStatus = async (orderId, itemId, status) => {
    const data = await api.patch(
      `/orders/vendor/${orderId}/items/${itemId}/status`,
      { status }
    );
    const updated = data;

    setOrders((prev) =>
      prev.map((o) =>
        o.id !== orderId
          ? o
          : {
              ...o,
              items: o.items.map((i) =>
                i.id === itemId
                  ? { ...i, ...updated, id: itemId, vendorStatus: status }
                  : i
              ),
            }
      )
    );

    const refreshed = await api.get("/orders/vendor/list");
    setOrders((refreshed || []).map(normalizeOrder));
  };

  const updateAdminOrderStatus = async (orderId, itemId, status) => {
    const data = await api.patch(
      `/orders/admin/${orderId}/items/${itemId}/status`,
      { status }
    );

    setOrders((prev) =>
      prev.map((o) =>
        o.id !== orderId
          ? o
          : {
              ...o,
              items: o.items.map((i) =>
                i.id === itemId
                  ? { ...i, ...data, id: itemId, vendorStatus: status }
                  : i
              ),
            }
      )
    );

    const refreshed = await api.get("/orders/admin/list");
    setOrders((refreshed || []).map(normalizeOrder));
  };

  const addIssue = async (data) => {
    const created = await api.post("/issues", data);
    const issue = normalizeIssue(created);
    setIssues((prev) => [issue, ...prev]);
    return issue;
  };

  const updateIssue = async (id, data) => {
    const updated = await api.patch(`/issues/${id}`, data);
    const issue = normalizeIssue(updated);
    setIssues((prev) => prev.map((x) => (x.id === id ? issue : x)));
    return issue;
  };

  const addProduct = async (data) => {
    const created = await api.post("/products", {
      ...data,
      imageUrl: data.image || data.imageUrl || "",
    });
    const product = normalizeProduct(created);
    setProducts((prev) => [product, ...prev]);
    return product;
  };

  const updateProduct = async (id, data) => {
    const updated = await api.put(`/products/${id}`, {
      ...data,
      imageUrl: data.image || data.imageUrl || "",
    });
    const product = normalizeProduct(updated);
    setProducts((prev) => prev.map((p) => (p.id === id ? product : p)));
    return product;
  };

  const deleteProduct = async (id) => {
    await api.delete(`/products/${id}`);
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const addAddress = async (data) => {
    const created = await api.post("/addresses", data);
    setAddresses((prev) => [normalizeAddress(created), ...prev]);
  };

  const updateAddress = async (id, data) => {
    const updated = await api.put(`/addresses/${id}`, data);
    const address = normalizeAddress(updated);
    setAddresses((prev) => prev.map((a) => (a.id === id ? address : a)));
  };

  const deleteAddress = async (id) => {
    await api.delete(`/addresses/${id}`);
    await loadUserData();
  };

  const setDefaultAddress = async (id) => {
    const updated = await api.patch(`/addresses/${id}/default`, {});
    const address = normalizeAddress(updated);
    setAddresses((prev) =>
      prev.map((a) =>
        a.userId === user.id ? { ...a, isDefault: a.id === address.id } : a
      )
    );
  };

  const addReview = async (productId, rating, review) => {
    try {
      const created = await api.post(`/reviews/product/${productId}`, {
        rating: Number(rating),
        review,
      });
      const normalized = normalizeReview(created);
      setReviews((prev) => [normalized, ...prev]);
      await loadProducts();
      return { ok: true };
    } catch (error) {
      return { ok: false, message: error.message };
    }
  };

  const loadProductReviews = async (productId) => {
    const data = await api.get(`/reviews/product/${productId}`);
    const normalized = (data || []).map(normalizeReview);

    setReviews((prev) => [
      ...prev.filter((r) => r.productId !== productId),
      ...normalized,
    ]);

    return normalized;
  };

  const deleteReview = async (id) => {
    await api.delete(`/reviews/${id}`);
    setReviews((prev) => prev.filter((r) => r.id !== id));
    await loadProducts();
  };

  const approveVendor = async (id) => {
    const updated = await api.patch(`/admin/vendors/${id}/approve`, {});
    const vendor = normalizeVendor(updated);
    setVendors((prev) => prev.map((v) => (v.id === id ? vendor : v)));
  };

  const rejectVendor = async (id) => {
    const updated = await api.patch(`/admin/vendors/${id}/reject`, {});
    const vendor = normalizeVendor(updated);
    setVendors((prev) => prev.map((v) => (v.id === id ? vendor : v)));
  };

  const deleteVendor = async (id) => {
    await api.delete(`/admin/vendors/${id}`);
    setVendors((prev) => prev.filter((v) => v.id !== id));
  };

  const updateUserStatus = async (id, status) => {
    const updated = await api.patch(`/admin/users/${id}/status`, { status });
    const next = normalizeUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === id ? next : u)));
  };

  const value = useMemo(
    () => ({
      user,
      token,
      loading,
      users,
      login,
      logout,
      registerUser,
      registerVendor,
      cartItems,
      cartTotal,
      addToCart,
      removeFromCart,
      updateCartQty,
      orders,
      placeOrder,
      loadOrder,
      updateVendorOrderStatus,
      updateAdminOrderStatus,
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      issues,
      addIssue,
      updateIssue,
      vendors,
      approveVendor,
      rejectVendor,
      deleteVendor,
      addresses,
      addAddress,
      updateAddress,
      deleteAddress,
      setDefaultAddress,
      reviews,
      addReview,
      loadProductReviews,
      deleteReview,
    }),
    [
      user,
      token,
      loading,
      users,
      cartItems,
      cartTotal,
      orders,
      products,
      issues,
      vendors,
      addresses,
      reviews,
    ]
  );

  return <C.Provider value={value}>{children}</C.Provider>;
}

export const useApp = () => useContext(C);
