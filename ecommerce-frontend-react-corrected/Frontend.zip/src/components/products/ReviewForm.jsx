import { useState } from "react";
import { useApp } from "../../context/AppContext";

export default function ReviewForm({ productId }) {
  const { addReview } = useApp();
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setMsg("");

    try {
      const r = await addReview(productId, rating, review.trim());

      if (!r.ok) {
        setMsg(r.message);
        return;
      }

      setReview("");
      setMsg("Review submitted.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card mt-3">
      <div className="card-body">
        <h5>Write a Review</h5>

        {msg && <div className="alert alert-info py-2">{msg}</div>}

        <form onSubmit={submit}>
          <select
            className="form-select mb-2"
            value={rating}
            onChange={(e) => setRating(Number(e.target.value))}
          >
            {[5, 4, 3, 2, 1].map((x) => (
              <option key={x} value={x}>
                {x}
              </option>
            ))}
          </select>

          <textarea
            className="form-control mb-2"
            rows="3"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            required
            placeholder="Your review"
          />

          <button className="btn btn-primary" disabled={busy}>
            {busy ? "Submitting..." : "Submit Review"}
          </button>
        </form>
      </div>
    </div>
  );
}
