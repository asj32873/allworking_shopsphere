require("dotenv").config();
const app = require("./app");
const connectDB = require("./config/db");

const PORT = process.env.PORT || 5000;

(async () => {
  try {
    await connectDB();
    app.listen(PORT, () => console.log(`ShopSphere API running on http://localhost:${PORT}`));
  } catch (error) {
    console.error("Startup failed:", error);
    process.exit(1);
  }
})();
