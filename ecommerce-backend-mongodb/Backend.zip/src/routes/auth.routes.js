const router = require("express").Router();
const controller = require("../controllers/auth.controller");
const validate = require("../middleware/validate");
const { authenticate } = require("../middleware/auth");
const { registerSchema, vendorRegisterSchema, loginSchema } = require("../validators/auth");

router.post("/register", validate(registerSchema), controller.register);
router.post("/vendor/register", validate(vendorRegisterSchema), controller.registerVendor);
router.post("/login", validate(loginSchema), controller.login);
router.post("/logout", authenticate, (req, res) => res.json({ success: true, message: "Logged out." }));
router.get("/me", authenticate, controller.me);

module.exports = router;
