const mongoose = require("mongoose");
const CartItem = require("../models/CartItem");
const Product = require("../models/Product");
const Order = require("../models/Order");
const OrderItem = require("../models/OrderItem");
const OrderStatusHistory = require("../models/OrderStatusHistory");
const Address = require("../models/Address");
const { ok, fail } = require("../utils/apiResponse");
const { VENDOR_NEXT_STATUS } = require("../utils/status");

async function createOrder(req, res) {
  const { addressId } = req.body;
  const address = await Address.findOne({
    _id: addressId,
    userId: req.user._id,
  });
  if (!address) return fail(res, "Delivery address not found.", 404);

  const cart = await CartItem.find({ userId: req.user._id }).populate(
    "productId",
  );
  if (!cart.length) return fail(res, "Cart is empty.", 400);

  for (const item of cart) {
    if (!item.productId)
      return fail(res, "A cart product no longer exists.", 409);
    if (item.quantity > item.productId.stock) {
      return fail(res, `Insufficient stock for ${item.productId.name}.`, 409);
    }
  }

  const totalAmount = cart.reduce(
    (sum, item) => sum + item.quantity * item.productId.price,
    0,
  );

  // For local MongoDB this works without a replica set. In production, wrap
  // stock decrement + order creation in a MongoDB transaction.
  const order = await Order.create({
    userId: req.user._id,
    addressId,
    status: "PLACED",
    totalAmount,
    orderedAt: new Date(),
    updatedAt: new Date(),
  });

  const orderItems = [];
  const history = [];

  for (const item of cart) {
    const product = item.productId;
    const updated = await Product.findOneAndUpdate(
      { _id: product._id, stock: { $gte: item.quantity } },
      { $inc: { stock: -item.quantity } },
      { new: true },
    );
    if (!updated) {
      await Order.findByIdAndDelete(order._id);
      await OrderItem.deleteMany({ orderId: order._id });
      return fail(
        res,
        `Stock changed while ordering ${product.name}. Please retry.`,
        409,
      );
    }

    const orderItem = await OrderItem.create({
      orderId: order._id,
      productId: product._id,
      vendorId: product.vendorId,
      name: product.name,
      quantity: item.quantity,
      unitPrice: product.price,
      vendorStatus: "PLACED",
    });

    orderItems.push(orderItem);
    history.push({
      orderId: order._id,
      orderItemId: orderItem._id,
      status: "PLACED",
      updatedBy: req.user._id,
      remarks: "Order placed",
    });
  }

  await OrderStatusHistory.insertMany(history);
  await CartItem.deleteMany({ userId: req.user._id });

  ok(res, await getOrderObject(order._id, req.user), "Order placed.", 201);
}

async function getOrderObject(orderId, requester) {
  const order = await Order.findById(orderId).populate("addressId").lean();
  if (!order) return null;

  let itemQuery = { orderId: order._id };
  if (requester.role === "VENDOR") itemQuery.vendorId = requester._id;

  const items = await OrderItem.find(itemQuery).lean();
  const itemIds = items.map((i) => i._id);
  const histories = await OrderStatusHistory.find({
    orderItemId: { $in: itemIds },
  })
    .sort({ timestamp: 1 })
    .lean();

  return {
    ...order,
    items: items.map((item) => ({
      ...item,
      tracking: histories
        .filter((h) => h.orderItemId.toString() === item._id.toString())
        .map((h) => ({
          status: h.status,
          date: h.timestamp,
          remarks: h.remarks,
        })),
    })),
  };
}

async function listMyOrders(req, res) {
  const orders = await Order.find({ userId: req.user._id })
    .sort({ orderedAt: -1 })
    .lean();
  const result = [];
  for (const order of orders) {
    result.push(await getOrderObject(order._id, req.user));
  }
  ok(res, result);
}

async function getById(req, res) {
  console.log("========== ORDER DETAILS ==========");
  console.log("req.params:", req.params);
  console.log("ID:", req.params.id);
  console.log("User:", req.user._id.toString());

  const order = await Order.findById(req.params.id);

  console.log("ORDER FOUND:", !!order);

  if (order) {
    console.log("DB ORDER ID:", order._id.toString());
    console.log("DB USER ID:", order.userId.toString());
  }

  console.log("===================================");

  if (!order) return fail(res, "Order not found.", 404);

  if (
    req.user.role === "USER" &&
    order.userId.toString() !== req.user._id.toString()
  ) {
    return fail(res, "Order not found.", 404);
  }

  if (req.user.role === "VENDOR") {
    const hasVendorItem = await OrderItem.exists({
      orderId: order._id,
      vendorId: req.user._id,
    });
    if (!hasVendorItem) return fail(res, "Order not found.", 404);
  }

  ok(res, await getOrderObject(order._id, req.user));
}

async function tracking(req, res) {
  const order = await Order.findById(req.params.id).lean();
  if (!order) return fail(res, "Order not found.", 404);

  if (
    req.user.role === "USER" &&
    order.userId.toString() !== req.user._id.toString()
  ) {
    return fail(res, "Order not found.", 404);
  }

  const items = await OrderItem.find({ orderId: order._id }).lean();
  const histories = await OrderStatusHistory.find({ orderId: order._id })
    .sort({ timestamp: 1 })
    .lean();

  ok(res, {
    orderId: order._id,
    items: items.map((item) => ({
      itemId: item._id,
      status: item.vendorStatus,
      tracking: histories.filter(
        (h) => h.orderItemId.toString() === item._id.toString(),
      ),
    })),
  });
}

async function vendorList(req, res) {
  const items = await OrderItem.find({ vendorId: req.user._id }).lean();
  const orderIds = [...new Set(items.map((i) => i.orderId.toString()))];
  const orders = await Order.find({ _id: { $in: orderIds } })
    .populate("userId", "name email phone")
    .sort({ orderedAt: -1 })
    .lean();

  ok(
    res,
    orders.map((order) => ({
      ...order,
      items: items.filter((i) => i.orderId.toString() === order._id.toString()),
    })),
  );
}

async function vendorUpdateStatus(req, res) {
  const { status, remarks } = req.body;
  const item = await OrderItem.findOne({
    _id: req.params.itemId,
    orderId: req.params.orderId,
    vendorId: req.user._id,
  });
  if (!item) return fail(res, "Order item not found for this vendor.", 404);

  const allowed = VENDOR_NEXT_STATUS[item.vendorStatus] || [];
  if (!allowed.includes(status)) {
    return fail(
      res,
      `Invalid vendor transition from ${item.vendorStatus} to ${status}.`,
      400,
    );
  }

  item.vendorStatus = status;
  await item.save();

  await OrderStatusHistory.create({
    orderId: item.orderId,
    orderItemId: item._id,
    status,
    updatedBy: req.user._id,
    remarks: remarks || `Vendor updated status to ${status}`,
  });

  await syncOrderStatus(item.orderId);
  ok(res, item, "Order item status updated.");
}

async function adminUpdateStatus(req, res) {
  const { status, remarks } = req.body;
  const item = await OrderItem.findOne({
    _id: req.params.itemId,
    orderId: req.params.orderId,
  });
  if (!item) return fail(res, "Order item not found.", 404);

  item.vendorStatus = status;
  await item.save();

  await OrderStatusHistory.create({
    orderId: item.orderId,
    orderItemId: item._id,
    status,
    updatedBy: req.user._id,
    remarks: remarks || `Admin updated status to ${status}`,
  });

  await syncOrderStatus(item.orderId);
  ok(res, item, "Order status updated.");
}

async function syncOrderStatus(orderId) {
  const items = await OrderItem.find({ orderId }).lean();
  if (!items.length) return;

  const statuses = items.map((i) => i.vendorStatus);
  let status = "PLACED";

  if (statuses.every((s) => s === "DELIVERED")) status = "DELIVERED";
  else if (statuses.every((s) => s === "OUT_FOR_DELIVERY" || s === "DELIVERED"))
    status = "OUT_FOR_DELIVERY";
  else if (
    statuses.every((s) =>
      ["DISPATCHED", "OUT_FOR_DELIVERY", "DELIVERED"].includes(s),
    )
  )
    status = "DISPATCHED";
  else if (
    statuses.every((s) =>
      ["PACKED", "DISPATCHED", "OUT_FOR_DELIVERY", "DELIVERED"].includes(s),
    )
  )
    status = "PACKED";
  else if (
    statuses.every((s) =>
      [
        "CONFIRMED",
        "PACKED",
        "DISPATCHED",
        "OUT_FOR_DELIVERY",
        "DELIVERED",
      ].includes(s),
    )
  )
    status = "CONFIRMED";
  else if (
    statuses.some((s) => s === "CANCELLED") &&
    statuses.every((s) => ["CANCELLED", "DELIVERED"].includes(s))
  )
    status = "CANCELLED";
  else status = "PLACED";

  await Order.findByIdAndUpdate(orderId, { status, updatedAt: new Date() });
}

async function adminList(req, res) {
  const orders = await Order.find()
    .populate("userId", "name email")
    .sort({ orderedAt: -1 })
    .lean();
  const ids = orders.map((o) => o._id);
  const items = await OrderItem.find({ orderId: { $in: ids } }).lean();
  ok(
    res,
    orders.map((o) => ({
      ...o,
      items: items.filter((i) => i.orderId.toString() === o._id.toString()),
    })),
  );
}

module.exports = {
  createOrder,
  listMyOrders,
  getById,
  tracking,
  vendorList,
  vendorUpdateStatus,
  adminUpdateStatus,
  adminList,
};
