const Review = require("../models/Review");
const Product = require("../models/Product");
const Order = require("../models/Order");
const OrderItem = require("../models/OrderItem");
const { ok, fail } = require("../utils/apiResponse");

async function listForProduct(req, res) {
  const reviews = await Review.find({ productId: req.params.productId })
    .populate("userId", "name")
    .sort({ createdAt: -1 });
  ok(res, reviews);
}

async function create(req, res) {
  const { rating, review } = req.body;
  const product = await Product.findById(req.params.productId);
  if (!product) return fail(res, "Product not found.", 404);

  const purchased = await Order.exists({
    userId: req.user._id,
    status: { $nin: ["CANCELLED", "RETURNED"] }
  });

  if (!purchased || !(await OrderItem.exists({
    orderId: { $in: await Order.find({ userId: req.user._id }).distinct("_id") },
    productId: product._id
  }))) {
    return fail(res, "Purchase required before reviewing.", 403);
  }

  if (await Review.exists({ productId: product._id, userId: req.user._id })) {
    return fail(res, "Already reviewed.", 409);
  }

  const created = await Review.create({
    productId: product._id,
    userId: req.user._id,
    rating: Number(rating),
    review
  });

  await recalculateRating(product._id);
  ok(res, created, "Review submitted.", 201);
}

async function update(req, res) {
  const review = await Review.findOneAndUpdate(
    { _id: req.params.id, userId: req.user._id },
    { rating: req.body.rating, review: req.body.review },
    { new: true, runValidators: true }
  );
  if (!review) return fail(res, "Review not found.", 404);
  await recalculateRating(review.productId);
  ok(res, review, "Review updated.");
}

async function remove(req, res) {
  const filter = req.user.role === "ADMIN"
    ? { _id: req.params.id }
    : { _id: req.params.id, userId: req.user._id };

  const review = await Review.findOneAndDelete(filter);
  if (!review) return fail(res, "Review not found.", 404);
  await recalculateRating(review.productId);
  ok(res, null, "Review deleted.");
}

async function recalculateRating(productId) {
  const stats = await Review.aggregate([
    { $match: { productId: productId } },
    { $group: { _id: "$productId", avg: { $avg: "$rating" }, count: { $sum: 1 } } }
  ]);

  const rating = stats[0] ? Number(stats[0].avg.toFixed(2)) : 0;
  const count = stats[0] ? stats[0].count : 0;
  await Product.findByIdAndUpdate(productId, { rating, reviewCount: count });
}

module.exports = { listForProduct, create, update, remove };
