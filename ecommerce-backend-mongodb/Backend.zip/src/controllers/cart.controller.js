const CartItem = require("../models/CartItem");
const Product = require("../models/Product");
const { ok, fail } = require("../utils/apiResponse");

async function getCart(req, res) {
  const items = await CartItem.find({ userId: req.user._id }).populate("productId").lean();
  const mapped = items.map(i => ({
    id: i._id,
    productId: i.productId._id,
    quantity: i.quantity,
    product: i.productId,
    subtotal: i.productId.price * i.quantity
  }));
  const total = mapped.reduce((sum, i) => sum + i.subtotal, 0);
  ok(res, { items: mapped, total });
}

async function addItem(req, res) {
  const { productId, quantity = 1 } = req.body;
  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 1) return fail(res, "Quantity must be a positive integer.");

  const product = await Product.findById(productId);
  if (!product) return fail(res, "Product not found.", 404);
  if (product.stock < qty) return fail(res, "Insufficient stock.", 409);

  const item = await CartItem.findOneAndUpdate(
    { userId: req.user._id, productId },
    { $inc: { quantity: qty } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );

  if (item.quantity > product.stock) {
    item.quantity = product.stock;
    await item.save();
  }

  ok(res, item, "Added to cart.");
}

async function updateItem(req, res) {
  const qty = Number(req.body.quantity);
  if (!Number.isInteger(qty) || qty < 1) return removeItem(req, res);

  const item = await CartItem.findOne({ _id: req.params.id, userId: req.user._id });
  if (!item) return fail(res, "Cart item not found.", 404);

  const product = await Product.findById(item.productId);
  if (!product) return fail(res, "Product no longer exists.", 404);
  if (qty > product.stock) return fail(res, "Quantity exceeds available stock.", 409);

  item.quantity = qty;
  await item.save();
  ok(res, item, "Cart updated.");
}

async function removeItem(req, res) {
  const item = await CartItem.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  if (!item) return fail(res, "Cart item not found.", 404);
  ok(res, null, "Cart item removed.");
}

module.exports = { getCart, addItem, updateItem, removeItem };
