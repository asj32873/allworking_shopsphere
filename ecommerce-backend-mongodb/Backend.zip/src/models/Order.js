const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  addressId: { type: mongoose.Schema.Types.ObjectId, ref: "Address", required: true },
  status: { type: String, enum: ["PLACED", "CONFIRMED", "PACKED", "DISPATCHED", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED", "RETURNED"], default: "PLACED", index: true },
  totalAmount: { type: Number, required: true, min: 0 },
  orderedAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model("Order", schema);
