const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  phone: { type: String, trim: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ["USER", "VENDOR", "ADMIN"], default: "USER", index: true },
  status: { type: String, enum: ["ACTIVE", "DISABLED"], default: "ACTIVE", index: true }
}, { timestamps: true });

module.exports = mongoose.model("User", schema);
