require("dotenv").config();
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const User = require("../models/User");
const Vendor = require("../models/Vendor");
const Address = require("../models/Address");
const Product = require("../models/Product");

async function run() {
  await connectDB();

  await Promise.all([
    User.deleteMany({}),
    Vendor.deleteMany({}),
    Address.deleteMany({}),
    Product.deleteMany({})
  ]);

  const hash = p => bcrypt.hash(p, Number(process.env.BCRYPT_SALT_ROUNDS || 12));

  const [userPassword, vendorPassword, adminPassword, pendingPassword] = await Promise.all([
    hash("user123"), hash("vendor123"), hash("admin123"), hash("vendor123")
  ]);

  const users = await User.insertMany([
    { name: "Demo User", email: "user@example.com", phone: "9876543210", passwordHash: userPassword, role: "USER", status: "ACTIVE" },
    { name: "Demo Vendor", email: "vendor@example.com", phone: "9876543211", passwordHash: vendorPassword, role: "VENDOR", status: "ACTIVE" },
    { name: "Demo Admin", email: "admin@example.com", phone: "9876543212", passwordHash: adminPassword, role: "ADMIN", status: "ACTIVE" },
    { name: "Pending Vendor", email: "pending@example.com", phone: "9876543213", passwordHash: pendingPassword, role: "VENDOR", status: "ACTIVE" }
  ]);

  const vendorUser = users.find(u => u.email === "vendor@example.com");
  const pendingUser = users.find(u => u.email === "pending@example.com");
  const normalUser = users.find(u => u.email === "user@example.com");

  await Vendor.insertMany([
    {
      userId: vendorUser._id,
      storeName: "Demo Electronics Store",
      email: vendorUser.email,
      phone: vendorUser.phone,
      storeAddress: "Bengaluru, Karnataka",
      status: "VERIFIED",
      verifiedAt: new Date()
    },
    {
      userId: pendingUser._id,
      storeName: "Pending Store",
      email: pendingUser.email,
      phone: pendingUser.phone,
      storeAddress: "Hubballi, Karnataka",
      status: "APPLIED"
    }
  ]);

  await Address.create({
    userId: normalUser._id,
    type: "Home",
    addressLine: "123 Demo Street",
    city: "Bengaluru",
    state: "Karnataka",
    pincode: "560001",
    isDefault: true
  });

  await Product.insertMany([
    {
      vendorId: vendorUser._id,
      name: "Sony WH-1000XM5",
      brand: "Sony",
      category: "AUDIO",
      price: 29999,
      stock: 25,
      rating: 4.7,
      description: "Premium wireless noise-cancelling headphones.",
      imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800"
    },
    {
      vendorId: vendorUser._id,
      name: "Sony Wireless Earbuds",
      brand: "Sony",
      category: "AUDIO",
      price: 8999,
      stock: 40,
      rating: 4.4,
      description: "Compact true wireless earbuds with rich sound.",
      imageUrl: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800"
    },
    {
      vendorId: vendorUser._id,
      name: "Mechanical Keyboard",
      brand: "Logitech",
      category: "ACCESSORIES",
      price: 4999,
      stock: 18,
      rating: 4.5,
      description: "Mechanical keyboard for work and gaming.",
      imageUrl: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800"
    },
    {
      vendorId: vendorUser._id,
      name: "4K Smart TV",
      brand: "Samsung",
      category: "TV",
      price: 42999,
      stock: 8,
      rating: 4.6,
      description: "4K smart television with streaming apps.",
      imageUrl: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800"
    }
  ]);

  console.log("Seed completed.");
  console.log("User: user@example.com / user123");
  console.log("Vendor: vendor@example.com / vendor123");
  console.log("Admin: admin@example.com / admin123");
  console.log("Pending vendor: pending@example.com / vendor123");

  await mongoose.disconnect();
}

run().catch(async err => {
  console.error(err);
  await mongoose.disconnect();
  process.exit(1);
});
